//
//  bilgiOlcerViewController.h
//  BilgiOlcer
//
//  Created by Emre Anil Gozel on 5/15/14.
//  Copyright (c) 2014 EmreAnilGozel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bilgiOlcerViewController : UIViewController

@end
