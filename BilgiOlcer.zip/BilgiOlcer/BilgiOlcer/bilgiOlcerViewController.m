//
//  bilgiOlcerViewController.m
//  BilgiOlcer
//
//  Created by Emre Anil Gozel on 5/15/14.
//  Copyright (c) 2014 EmreAnilGozel. All rights reserved.
//

#import "bilgiOlcerViewController.h"

@interface bilgiOlcerViewController ()

@end

@implementation bilgiOlcerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
